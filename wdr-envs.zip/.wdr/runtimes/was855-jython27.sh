WAS_HOME="/data/was855client"
WSADMIN_CLASS_PATH=${WAS_HOME}/optionalLibraries/jython27/jython.jar:${WAS_HOME}/runtimes/com.ibm.ws.admin.client_8.5.0.jar:${WAS_HOME}/plugins/com.ibm.ws.security.crypto.jar
JYTHON_HOME=${WAS_HOME}/optionalLibraries/jython27
JYTHON_VERSION="2.7"
