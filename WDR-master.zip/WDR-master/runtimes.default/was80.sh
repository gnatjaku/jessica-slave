WAS_HOME="/opt/IBM/WebSphere80/AppClient"
WSADMIN_CLASS_PATH=${WAS_HOME}/optionalLibraries/jython/jython.jar:${WAS_HOME}/runtimes/com.ibm.ws.admin.client_8.0.0.jar:${WAS_HOME}/plugins/com.ibm.ws.security.crypto.jar
JYTHON_VERSION="2.1"
