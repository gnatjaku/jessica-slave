WAS_HOME="/opt/IBM/WebSphere85/AppClient"
WSADMIN_CLASS_PATH=${WAS_HOME}/optionalLibraries/jython/jython.jar:${WAS_HOME}/runtimes/com.ibm.ws.admin.client_8.5.0.jar:${WAS_HOME}/plugins/com.ibm.ws.security.crypto.jar
JYTHON_VERSION="2.1"
