WAS_HOME="/opt/IBM/WebSphere61/AppClient"
WSADMIN_CLASS_PATH=${WAS_HOME}/optionalLibraries/jython/jython.jar:${WAS_HOME}/runtimes/com.ibm.ws.admin.client_6.1.0.jar:${WAS_HOME}/plugins/com.ibm.ws.security.crypto_6.1.0.jar
JYTHON_VERSION="2.1"
