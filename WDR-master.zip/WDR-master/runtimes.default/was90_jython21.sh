WAS_HOME=/opt/IBM/WebSphere90/AppClient
WAS_JAVA_HOME=${WAS_HOME}/java/8.0
WSADMIN_CLASS_PATH=${WAS_HOME}/optionalLibraries/jython21/jython.jar:${WAS_HOME}/runtimes/com.ibm.ws.admin.client.forJython21_9.0.jar:${WAS_HOME}/plugins/com.ibm.ws.security.crypto.jar
JYTHON_VERSION=2.1
JYTHON_HOME=${WAS_HOME}/optionalLibraries/jython21
JYTHON_PATH=${WAS_HOME}/optionalLibraries/jython21/Lib
