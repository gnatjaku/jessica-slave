topology = {
    'cellName': 'vagrant',
    'nodeName': 'vagrant',
    'serverName': 'server1',
}
class Topology:
    cellName, nodeName, serverName = (
        topology['cellName'], topology['nodeName'], topology['serverName']
    )
