#!/bin/sh

# runtimes.default.bat
#
# do not modify this file
# update of WDR may overwrite your changes
#
# in order to customize WAS client paths: make a copy of this file, save it as "runtimes.sh"
# and customize that "runtimes.sh" script

WAS61_RUNTIME_HOME="/opt/IBM/WebSphere61/AppClient"
WAS61_JYTHON_VERSION="2.1"
WAS70_RUNTIME_HOME="/opt/IBM/WebSphere7/AppClient"
WAS70_JYTHON_VERSION="2.1"
WAS80_RUNTIME_HOME="/opt/IBM/WebSphere80/AppClient"
WAS80_JYTHON_VERSION="2.1"
WAS85_RUNTIME_HOME="/opt/IBM/WebSphere85/AppClient"
WAS85_JYTHON_VERSION="2.1"
